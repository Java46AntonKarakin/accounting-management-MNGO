package telran.spring.accounting.entities;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import telran.spring.accounting.model.Account;

@Document(collection = "accounts")
public class AccountEntity {
	@Id
	private String email;
	private String password;
	private LocalDateTime expiration;
	private boolean revoked;
	private String [] roles;
	
	public static AccountEntity  of(Account accountDto) {
		var account = new AccountEntity ();
		account.email = accountDto.username;
		account.password = accountDto.password;
		account.roles = accountDto.roles;
		account.revoked = false;
		return account;
	}

	public final String [] getroles() {
		return roles;
	}

	public final void setroles(String [] roles) {
		this.roles = roles;
	}
	
	public final String getPassword() {
		return password;
	}
	
	public final void setPassword(String password) {
		this.password = password;
	}

	public final LocalDateTime getExpiration() {
		return expiration;
	}

	public final void setExpiration(LocalDateTime expiration) {
		this.expiration = expiration;
	}

	public final boolean isRevoked() {
		return revoked;
	}

	public final void setRevoked(boolean revoked) {
		this.revoked = revoked;
	}

	public final String getEmail() {
		return email;
	}
}
