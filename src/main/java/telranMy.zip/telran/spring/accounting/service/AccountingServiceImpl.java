package telran.spring.accounting.service;

import java.util.HashMap;

import org.slf4j.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import java.io.*;
import java.time.LocalDateTime;

import telran.spring.accounting.entities.AccountEntity;
import telran.spring.accounting.model.Account;
import telran.spring.accounting.repo.AccountRepository;

@Service
@Transactional
public class AccountingServiceImpl implements AccountingService {
	private static Logger LOG = LoggerFactory.getLogger(AccountingService.class);
	@Value("${app.admin.username:admin}")
	private String admin;
	private PasswordEncoder passwordEncoder;
	private UserDetailsManager userDetailsManager;
	private AccountRepository accounts;
	@Value("${app.password.period:100}")
	private int passwordPeriod; // pswd is alive, h

	public AccountingServiceImpl(PasswordEncoder passwordEncoder, UserDetailsManager userDetailsManager, AccountRepository accounts) {
		this.accounts = accounts;
		this.passwordEncoder = passwordEncoder;
		this.userDetailsManager = userDetailsManager;
	}

	@Override
	public boolean addAccount(Account account) {
		boolean res = false;
		if (!account.username.equals(admin) && !accounts.existsById(account.username)) {
			res = true;
			account.password = passwordEncoder.encode(account.password);
			AccountEntity accDoc = AccountEntity.of(account);
			accDoc.setExpiration(LocalDateTime.now().plusHours(passwordPeriod));
			accounts.save(accDoc);
			userDetailsManager.createUser(
					User.withUsername(account.username).password(account.password).roles(account.roles).build());
		}
		return res;
	}

	@Override
	public boolean deleteAccount(String username) {
		boolean res = false;
		if (accounts.existsById(username)) {
			res = true;
			accounts.deleteById(username);
			userDetailsManager.deleteUser(username);
		}
		return res;
	}

	@Override
	public boolean updateAccount(Account account) {
		boolean res = false;
		AccountEntity accountDocument = accounts.findById(account.username).orElse(null);
		if (accountDocument != null) {
			res = true;
			account.password = passwordEncoder.encode(account.password);
			accounts.put(account.username, account);
			userDetailsManager.updateUser(
					User.withUsername(account.username).password(account.password).roles(account.role).build());
		}
		return res;
	}

	@Override
	public boolean isExists(String username) {
		return accounts.containsKey(username);
	}

	@PreDestroy
	void saveAccounts() {
		try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName))) {
			output.writeObject(accounts);
			LOG.debug("accounts saved to file {}", fileName);
		} catch (Exception e) {
			LOG.error("saving to file caused exception {}", e.getMessage());
		}
	}

	@PostConstruct
	void restoreAccounts() {
		try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(fileName))) {
			accounts = (HashMap<String, Account>) input.readObject();
			for (Account acc : accounts.values()) {
				userDetailsManager
						.createUser(User.withUsername(acc.username).password(acc.password).roles(acc.role).build());
			}
			LOG.debug("accounts {} has been restored", accounts.keySet());
		} catch (FileNotFoundException e) {
			LOG.warn("file {} doesn't exists", fileName);
			accounts = new HashMap<>();
		} catch (Exception e) {
			LOG.error("error at restoring accounts {}", e.getMessage());
		}
	}
}
